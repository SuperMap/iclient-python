# Deprecated alias for xml.etree.ElementTree

from xml.etree.ElementTree import *
